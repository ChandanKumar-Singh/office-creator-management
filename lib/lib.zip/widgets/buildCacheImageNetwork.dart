import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

Widget buildCachedNetworkImage({required String imageUrl}) {
  return CachedNetworkImage(
    imageUrl: imageUrl,
    imageBuilder: (context, imageProvider) => Image.network(
      imageUrl,
      fit: BoxFit.fill,
    ),
    placeholder: (context, url) => const Padding(
      padding: EdgeInsets.all(8.0),
      child: CircularProgressIndicator(),
    ),
    errorWidget: (context, url, error) => Image.asset(
      'assets/images/placeholder.jfif',
      fit: BoxFit.cover,
    ),
  );
}
